# Escape sequence
# Collecting data
nigerian_dish = input("Enter a nigeria dish: ")
state = input("Enter state where it is popular in: ")
# output
print(f"{nigerian_dish}\n\t{state}")