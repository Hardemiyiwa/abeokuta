# Collecting User Details
name = input("Enter your name: ")
age = int(input("How old are you? "))

# print out
print(f"Welcome {name}, you are {age} years old")