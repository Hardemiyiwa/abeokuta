# Student School Registration
# Collecting student data
name = input("Enter your name: ")
student_class = input("What class are you? ")
state_of_origin = input("Enter your state of origin: ")

# Displaying the output
print("Student " + name + " is in " + student_class + " and is from " + state_of_origin)



