# Collecting Data 
garri_price_per_paint = float(input("How much is the price of garri per paint in naira? "))

# Print out
print(f"The amount of garri per paint is #{garri_price_per_paint}K")