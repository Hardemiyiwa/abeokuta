# Mixing Data Types
# collect input
age = int(input("How old are you? "))
height = float(input("Enter your height in \"m\": "))
name = input("Enter your name: ")

# output
print(f"Hello {name}, you are {age} years old, you are {height}m tall")