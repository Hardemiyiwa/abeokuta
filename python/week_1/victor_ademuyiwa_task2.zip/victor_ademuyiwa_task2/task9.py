# Nigeria festival
# collecting output
festival_name = input("Enter the name of the festival: ")
location = input("Enter the location: ")
month_held = input("Enter the month it will be held: ")

# output
print(f"\"{festival_name}\" festiva will be held at {location} on {month_held}") 